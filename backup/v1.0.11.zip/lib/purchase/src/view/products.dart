const String basePlanId = 'srikot_company';
const String staffId = 'staff';
const String userId = 'user';
const String enterpriseBasePlanId = 'srikot_app';
const String enterpriseStaffId = 'staff_enterprise';
const String enterpriseuserId = 'user_enterprise';
