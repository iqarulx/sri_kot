export 'src/view/app.dart';
