String serviceData = '''
{
  "type": "service_account",
  "project_id": "sri-kot",
  "private_key_id": "feccd5e68d169f56b86d670cda70b1f4a482c98c",
  "private_key": "-----BEGIN PRIVATE KEY-----\\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCWWKbhRxFuqv3S\\nuJgcN7zCgcwJVSfjDZYkOlDDUFY3HKxYRDt446BTHdwm8H4Bk6YF/HTc2JOmAg8L\\nYKqrUmnmdmy1+LN5a+JfKDKRpht5o8J1VnnjMemfyXSc91f1a/6POSgvxLFauydB\\n6CKImUgvKskFwRausNu8dMeKrkxeDSQXj7PAemVtOuoR8Bh/z25usZeq1xCafbLn\\nbUuT8SXi1X4usobCBYZcQzScC5EyzWzHhpAtChst2l7R0IyzLrti8yuQJk5AlEHH\\nSWkCQaJFbakJCnOHpI7opWo256zXQgghW1IzFqWrGJ9+dM0tMPfWH5pHfQGpKquC\\nTsFoyS99AgMBAAECggEACRgKqNschFLZo73Tp/bjg+mUkGBZipcFsZV8N7XFYto1\\n2IIkDZKWXecTLAdlVi4UOQ3fE1HfhTqTQC86k4tNtlY/Pbbx3PkE48sxwXQux3au\\n0MJVNBD1HlulCJUmrMS5mV5hMZmwCpqbny86q4PuBSBaF9WCmQVy/R0cY4vAbC3Y\\n6SUw2hQhfZM/0ERy1lQQT4x9IfX5SFyFm+Wko/yF+/XF1kdrB8ZLSCdsVQdHABZV\\nQKDCsDtpi3GFb0DEufX7EusQCZkSnNsf9T2NUnZTfctH3/JSp6QaFyVM9WshTm8N\\no3hQngR4TCADjYEMB8c8UWm7FZ51L5QG8zMh1Kb6FwKBgQDS3LkRZtrBKPD7Vpie\\nL8sPPo7vE+20cu0nD8923MwNFzxM/p64o7BuoxeO/qpzyEEY+Kt7e85ZLZdnJjOj\\nEjc0zMTHPGTJ1qDcV5VozRXUOi+yfwUKnZjyHG/hCb1ufPXTF/N92pe+qPvZTgTi\\nhHMF3lIDNlQwHAwLUNdMTL8m0wKBgQC2h6Y4Ess3LAsFE0TvynJwU581PZxICszz\\nEKgE5x3xfkRhQ5OsEpVy9VHSIfKfseZmg0cGSqLB3+3E3gRiJTTCA0rkzERrXjh+\\n2cSc9FLYojfRK+9tROywk0oLyZWAkYqrnB7a+C650NZiQ5dsmR9TM80D+In6byxY\\n21t6x9b+bwKBgQC+30Y3Vl+WkjTxjsXAC4tIVVyVVfjKa234+frWoa+j+fB/0cxj\\nXukKfV+J9UTeYdtre03fDYcQepCespnzdz258dH+d9DUVBBw5Gc+4sZrwfADJ6+s\\nmFQmdU9g6awsI7lySDAFMKZD1DuFzXXmhfaIzWJ3veofUoQkih0Z2C8AOQKBgB78\\nzHU8i49kRMKp0Mw8vEzhhWfOe9enLcAeFcgvTGARJZ61kD5oMUMA7tETvlLqKslA\\nhDBHP3ZWg9EmN+xJkLlXQcGyA/OOXVz7r2tN9zqb34n9QXp1dxFLEAkMQfs/uiEE\\nMiDOfXBCSgMIoo5nOHAxnR6NdS807HxxUQh5IMC1AoGBAJHov/zN/jzGycIRvxvp\\n8DeQdAKMrvyHjl5/Ln11LUJ77QRtP7wEU4I0UQijHcO/8BfsMsw0aHM9C+6/CFRr\\n9hG7WbdtJEMvl8aNqHo5fnQPBW1IvmCpIguzZ5RTqWST+9sd6zHCsCPHH4WEKcKB\\nrKfuzypqE4FA5+Q1F2splFdx\\n-----END PRIVATE KEY-----\\n",
  "client_email": "sri-kot-app@sri-kot.iam.gserviceaccount.com",
  "client_id": "102840397379889369788",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/sri-kot-app%40sri-kot.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
}
''';
