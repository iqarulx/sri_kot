class Strings {
  static String profileImg =
      "https://firebasestorage.googleapis.com/v0/b/sri-kot.appspot.com/o/demos%2Fuser.jpg?alt=media&token=81be0f08-57a8-4f7a-9258-2f0cbb71c3ec";
  static String productImg =
      "https://firebasestorage.googleapis.com/v0/b/sri-kot.appspot.com/o/demos%2Fproduct.jpg?alt=media&token=3a2931dd-3e97-413d-a69b-140867ba02a0";

  static String productTemplate =
      "https://firebasestorage.googleapis.com/v0/b/sri-kot.appspot.com/o/demos%2FProduct%20Template.xlsx?alt=media&token=fcf31846-dc0f-4d46-ba7a-7cfcb2670b67";

  static String productTemplateWithData =
      "https://firebasestorage.googleapis.com/v0/b/sri-kot.appspot.com/o/demos%2FProduct%20Template%20with%20data.xlsx?alt=media&token=2ea4d22e-72f1-444d-91ca-10d87bbe12ab";
}
