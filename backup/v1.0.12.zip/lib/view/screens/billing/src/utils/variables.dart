import '../../../../../provider/provider.dart';

BilingPageProvider billPageProvider = BilingPageProvider();
BilingPageProvider billPageProvider2 = BilingPageProvider();
