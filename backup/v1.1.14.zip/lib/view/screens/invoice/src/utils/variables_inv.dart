import '/provider/provider.dart';

BilingPageProvider billPageProviderInv = BilingPageProvider();
BilingPageProvider billPageProvider2Inv = BilingPageProvider();
