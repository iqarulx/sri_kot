import 'package:flutter/material.dart';

class License extends StatefulWidget {
  const License({super.key});

  @override
  State<License> createState() => _LicenseState();
}

class _LicenseState extends State<License> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
